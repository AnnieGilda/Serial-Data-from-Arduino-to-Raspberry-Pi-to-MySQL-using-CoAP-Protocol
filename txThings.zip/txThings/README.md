txThings
========

txThings - CoAP library for Twisted framework

txThings is a Python implementation of Constrained
Application Protocol (CoAP):

http://tools.ietf.org/html/rfc7252


txThings is based on Twisted - asynchronous I/O
framework and networking engine written in Python.

http://twistedmatrix.com/


txThings uses MIT License (like Twisted itself).

http://opensource.org/licenses/mit-license.php

Copyright (c) 2012 Maciej Wasilak

http://sixpinetrees.blogspot.com/
